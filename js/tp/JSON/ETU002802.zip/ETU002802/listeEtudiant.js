var ListeEtudiants = {
    "Etudiants": [
        {
            "numero_etudiant": "2802",
            "nom": "Rakotoarimanana",
            "prenom": "Henintsoa",
            "moyenne_s1": 80,
            "moyenne_s2": 70,

            "matieres": [
                {
                    "nom_matiere": "Mathematique",
                    "note_semestre_1": 50,
                    "note_semestre_2": 85
                },
                {
                    "nom_matiere": "Programmation",
                    "note_semestre_1": 40,
                    "note_semestre_2": 62
                },
                {
                    "nom_matiere": "Reseau",
                    "note_semestre_1": 78,
                    "note_semestre_2": 90
                },
                {
                    "nom_matiere": "Algebre",
                    "note_semestre_1": 60,
                    "note_semestre_2": 77
                },
                {
                    "nom_matiere": "Anglais",
                    "note_semestre_1": 81,
                    "note_semestre_2": 69
                }
            ]
        }
    ]
};

